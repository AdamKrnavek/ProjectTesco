﻿using Microsoft.Win32;
using System.Data;
using System.Windows;
using System.Collections.Generic;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace TescoSwZadani
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            tmEndDate.SelectedDate = DateTime.Today;
        }

        private void LoadXML(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "XML Files (*.xml)|*.xml";
            openFileDialog.Title = "Prosím vyberte XML soubor";

            if (openFileDialog.ShowDialog() == true)
            {
                string filePath = openFileDialog.FileName;
                DataSet dataSet = new DataSet();
                dataSet.ReadXml(filePath);
                DataTable dataTable = dataSet.Tables[0];
                dataGrid.ItemsSource = dataTable.DefaultView;
            }
        }

        private void ShowResults(object sender, RoutedEventArgs e)
        {
            if (dataGrid.Items.Count > 0)
            {
                DataTable dataTable = ((DataView)dataGrid.ItemsSource).ToTable();
                DataTable resultTable = new DataTable();
                resultTable.Columns.Add("Název modelu\nCena bez DPH");
                resultTable.Columns.Add("Cena s DPH");

                Dictionary<string, double> modelPriceSum = new Dictionary<string, double>();
                Dictionary<string, double> modelTaxSum = new Dictionary<string, double>();

                foreach (DataRow row in dataTable.Rows)
                {
                    if (DateTime.TryParse(row.Field<string>("DatumProdeje"), out DateTime saleDate))
                    {
                        if (saleDate > TmStartDate.SelectedDate && saleDate < tmEndDate.SelectedDate)
                        {
                            string model = row.Field<string>("NazevModelu") ?? "";
                            double price;
                            double tax;
                            double.TryParse(row.Field<string>("Cena"), out price);
                            double.TryParse(row.Field<string>("DPH"), out tax);
                            double priceWithTax = price + price * (tax / 100);

                            if (saleDate.DayOfWeek == DayOfWeek.Saturday || saleDate.DayOfWeek == DayOfWeek.Sunday)
                            {
                                if (modelPriceSum.ContainsKey(model))
                                {
                                    modelPriceSum[model] += price;
                                }
                                else
                                {
                                    modelPriceSum[model] = price;
                                }

                                if (modelTaxSum.ContainsKey(model))
                                {
                                    modelTaxSum[model] += priceWithTax;
                                }
                                else
                                {
                                    modelTaxSum[model] = priceWithTax;
                                }
                            }
                        }
                    }
                }

                foreach (var item in modelPriceSum)
                {
                    double priceWithTax = modelTaxSum[item.Key];
                    resultTable.Rows.Add(string.Format("{0}\n{1:F2}", item.Key, item.Value), priceWithTax.ToString("F2"));
                }

                ResultWindow resultWindow = new ResultWindow();
                resultWindow.resultDataGrid.ItemsSource = resultTable.DefaultView;
                resultWindow.Show();
            }
            else
            {
                MessageBox.Show("Musíš nejdříve zadat XML soubor", "Pozor", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void ClearXMLBtn_Click(object sender, RoutedEventArgs e)
        {
            if (dataGrid.Items.Count > 0)
            {
                dataGrid.ItemsSource = null;
                tmEndDate.SelectedDate = DateTime.Now;
                TmStartDate.SelectedDate = new DateTime(2000, 1, 1);
            }
            else
            {
                MessageBox.Show("Musíš nejdříve zadat XML soubor", "Pozor", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }
    }
}
